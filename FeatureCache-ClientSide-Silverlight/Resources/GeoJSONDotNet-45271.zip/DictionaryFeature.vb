﻿Public Class DictionaryFeature(Of T)
    Inherits Feature(Of T, Dictionary(Of String, String))
End Class