﻿Public Class Polygon
    Inherits Geometry(Of Double()())

    Public Sub New()
        MyBase.New(ObjectType.Polygon)
    End Sub
End Class