﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("GeoJSON.NET")> 
<Assembly: AssemblyProduct("GeoJSON.NET")> 
<Assembly: AssemblyCopyright("Copyright © Samu Lang 2010")> 
<Assembly: AssemblyVersion("0.1.*")> 
<Assembly: AssemblyFileVersion("0.1.*")> 

<Assembly: ComVisibleAttribute(False)> 