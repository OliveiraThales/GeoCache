﻿Public Enum ObjectType
    Point
    GeometryCollection
    Feature
    FeatureCollection
    MultiPoint
    LineString
    MultiLineString
    Polygon
    MultiPolygon
End Enum