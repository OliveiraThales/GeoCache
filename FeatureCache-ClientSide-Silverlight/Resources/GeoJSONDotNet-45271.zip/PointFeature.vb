﻿Public Class PointFeature(Of T)
    Inherits Feature(Of Point, T)
End Class